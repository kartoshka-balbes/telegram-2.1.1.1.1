import React, { useState } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { Search, Star, Trash2, Reply, Forward, ArrowLeft, Send, Inbox, Paperclip } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

type Cat = 'Задолженность' | 'Розыск' | 'Обвинение' | 'Оскорбление' | 'Долг' | 'Предупреждение';

interface Email {
  id: string;
  sender: string;
  email: string;
  subject: string;
  date: string;
  body: string;
  cat: Cat;
  initials: string;
  isStarred?: boolean;
  unread?: boolean;
  attachment?: string;
}

const CAT_STYLE: Record<Cat, string> = {
  Задолженность: 'bg-amber-400/20 text-amber-300 border-amber-400/40',
  Розыск: 'bg-red-500/20 text-red-300 border-red-500/40',
  Обвинение: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
  Оскорбление: 'bg-fuchsia-500/20 text-fuchsia-300 border-fuchsia-500/40',
  Долг: 'bg-orange-500/20 text-orange-300 border-orange-500/40',
  Предупреждение: 'bg-sky-400/20 text-sky-300 border-sky-400/40',
};

const INITIAL: Email[] = [
  { id: '1', sender: 'ФССП России', email: 'no-reply@fssp.gov.ru', subject: 'Задолженность по исполнительному производству № 84920/26', date: 'Сегодня, 10:15', cat: 'Задолженность', initials: 'ФС', unread: true, isStarred: true, attachment: 'postanovlenie_84920.pdf',
    body: 'Уведомляем вас о наличии непогашенной задолженности в размере 4 812 390 ₽. Срок добровольной оплаты истёк 14 дней назад. В случае неуплаты в течение 3 рабочих дней будет наложен арест на имущество и ограничен выезд за пределы страны.' },
  { id: '2', sender: 'НЦБ Интерпола', email: 'ncb-moscow@interpol.example', subject: 'Уведомление о международном розыске', date: 'Сегодня, 09:02', cat: 'Розыск', initials: 'ИП', unread: true,
    body: 'Ваши данные внесены в международную базу разыскиваемых лиц (красное уведомление № 2026/A-8841). Просим вас не покидать место проживания и дождаться связи с представителем национального бюро. Покинуть страну до выяснения обстоятельств невозможно.' },
  { id: '3', sender: 'Следственный комитет', email: 'sk-priem@sledcom.example', subject: 'Постановление о привлечении в качестве обвиняемого', date: 'Вчера, 18:40', cat: 'Обвинение', initials: 'СК', unread: true, attachment: 'postanovlenie_obvinenie.pdf',
    body: 'Вам предъявлено обвинение в систематическом нарушении установленного порядка пользования мобильным приложением. Явка к следователю обязательна. При неявке к вам будет применён привод.' },
  { id: '4', sender: 'Неизвестный отправитель', email: 'anon7731@mail.example', subject: 'Мы всё о вас знаем', date: 'Вчера, 14:21', cat: 'Оскорбление', initials: '??',
    body: 'Вы скучный, предсказуемый человек. Ваши сообщения читают только из жалости, а ваша аватарка вызывает недоумение. Не отвечайте на это письмо, вам всё равно нечего сказать.' },
  { id: '5', sender: 'Банк «Единый»', email: 'collection@edinyi-bank.example', subject: 'Просроченный долг по кредитному договору', date: '06.08.2026', cat: 'Долг', initials: 'БЕ',
    body: 'По кредитному договору № 5521-К у вас образовалась просроченная задолженность в размере 318 740 ₽, включая пени и штрафы. Сумма ежедневно увеличивается. Для урегулирования обратитесь в отделение банка.' },
  { id: '6', sender: 'Коллекторское агентство «Возврат»', email: 'return@collector.example', subject: 'Последнее предупреждение', date: '05.08.2026', cat: 'Предупреждение', initials: 'КВ',
    body: 'Это последнее предупреждение. В случае отказа от добровольного погашения долга мы вынуждены передать материалы в суд и уведомить вашего работодателя. Ждём вашего звонка в течение суток.' },
  { id: '7', sender: 'Федеральная налоговая служба', email: 'nalog@fns.example', subject: 'Требование об уплате недоимки', date: '03.08.2026', cat: 'Задолженность', initials: 'ФН', attachment: 'trebovanie_nedoimka.pdf',
    body: 'За вами числится недоимка по налогу на имущество и налогу на использование воздуха в размере 96 410 ₽. Просим погасить задолженность в течение 8 рабочих дней. Дальнейшее взыскание будет произведено за счёт денежных средств на счетах.' },
  { id: '8', sender: 'Арбитражный суд', email: 'office@arbitr.example', subject: 'Исковое заявление о взыскании долга', date: '01.08.2026', cat: 'Долг', initials: 'АС',
    body: 'В отношении вас подан иск о взыскании долга на сумму 1 205 000 ₽. Судебное заседание назначено на ближайший вторник. Неявка не является препятствием для рассмотрения дела и вынесения решения.' },
  { id: '9', sender: 'Администрация подъезда', email: 'dom@zhilkom.example', subject: 'Претензия: оскорбление жильцов', date: '30.07.2026', cat: 'Оскорбление', initials: 'ЖК',
    body: 'Жильцы подъезда сообщают, что вы грубо отзывались о соседях и демонстративно пренебрегали общественными нормами. Требуем принести извинения и прекратить оскорбительное поведение.' },
  { id: '10', sender: 'Служба безопасности', email: 'security@guard.example', subject: 'Обвинение в подозрительной активности', date: '28.07.2026', cat: 'Обвинение', initials: 'СБ',
    body: 'Система зафиксировала подозрительную активность с вашего устройства: нажатие кнопок чаще допустимого. Вы обвиняетесь в неоправданном любопытстве. Ожидайте дальнейших указаний.' },
  { id: '11', sender: 'Управляющая компания', email: 'uk@zhkh.example', subject: 'Задолженность за коммунальные услуги', date: '25.07.2026', cat: 'Задолженность', initials: 'УК',
    body: 'По вашему лицевому счёту числится задолженность по оплате коммунальных услуг за 14 месяцев на сумму 87 320 ₽. При непогашении будет ограничена подача воды и электричества.' },
  { id: '12', sender: 'Таможенная служба', email: 'customs@fts.example', subject: 'Предупреждение о досмотре', date: '20.07.2026', cat: 'Предупреждение', initials: 'ТС',
    body: 'При следующем пересечении границы вы будете подвергнуты расширенному досмотру. Просим заранее подготовить все документы и объяснить происхождение ваших вещей.' },
  { id: '13', sender: '+7 (900) 000-00-13', email: 'sms-gateway@mail.example', subject: 'Ты нам должен', date: '18.07.2026', cat: 'Долг', initials: '13',
    body: 'Ты помнишь, что должен нам. Мы тоже помним. Срок до пятницы. Не делай вид, что тебя нет дома.' },
];

const CATS: Array<'Все' | Cat> = ['Все', 'Задолженность', 'Розыск', 'Обвинение', 'Оскорбление', 'Долг', 'Предупреждение'];

export const MailTool: React.FC<ToolProps> = ({ onClose }) => {
  const [emails, setEmails] = useState<Email[]>(INITIAL);
  const [selected, setSelected] = useState<Email | null>(null);
  const [query, setQuery] = useState('');
  const [cat, setCat] = useState<'Все' | Cat>('Все');
  const [reply, setReply] = useState('');
  const [toast, setToast] = useState('');

  const showToast = (t: string) => {
    setToast(t);
    window.setTimeout(() => setToast(''), 2400);
  };

  const toggleStar = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setEmails((prev) => prev.map((m) => (m.id === id ? { ...m, isStarred: !m.isStarred } : m)));
  };

  const openMail = (m: Email) => {
    soundManager.playBeep(900, 0.03);
    setEmails((prev) => prev.map((x) => (x.id === m.id ? { ...x, unread: false } : x)));
    setSelected(m);
    setReply('');
  };

  const sendReply = () => {
    if (!reply.trim()) return;
    setReply('');
    showToast('Ответ отправлен');
  };

  const remove = (id: string) => {
    setEmails((prev) => prev.filter((m) => m.id !== id));
    setSelected(null);
    showToast('Письмо удалено');
  };

  const q = query.trim().toLowerCase();
  const list = emails
    .filter((m) => cat === 'Все' || m.cat === cat)
    .filter((m) => !q || m.sender.toLowerCase().includes(q) || m.subject.toLowerCase().includes(q) || m.body.toLowerCase().includes(q));

  return (
    <ToolWrapper title="Электронная почта" onClose={onClose}>
      <div className="max-w-2xl mx-auto w-full flex-1 flex flex-col select-none">
        {toast && (
          <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-[#202124] text-white border border-white/15 px-4 py-2.5 rounded-lg text-[14px] pointer-events-none">{toast}</div>
        )}

        {!selected ? (
          <>
            {/* Поиск */}
            <div className="flex items-center gap-2 rounded-full bg-white/[0.08] px-4 py-2.5 mb-3">
              <Search className="w-4 h-4 text-gray-400" />
              <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Поиск в почте" className="flex-1 min-w-0 bg-transparent outline-none text-[15px] text-white placeholder-gray-500" />
              <span className="flex items-center gap-1 text-[12px] text-gray-400"><Inbox className="w-4 h-4" />{emails.length}</span>
            </div>

            {/* Категории */}
            <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2 mb-1">
              {CATS.map((c) => (
                <button
                  key={c}
                  onClick={() => setCat(c)}
                  className={`shrink-0 px-3.5 py-1.5 rounded-lg text-[13px] cursor-pointer border ${cat === c ? 'bg-[#8f9bff] text-[#0b0d13] border-transparent font-medium' : 'bg-white/[0.06] text-gray-300 border-white/10'}`}
                >
                  {c}
                </button>
              ))}
            </div>

            {/* Список */}
            <div className="flex-1 overflow-y-auto">
              {list.length === 0 && <div className="p-8 text-center text-gray-500 text-[14px]">Писем нет</div>}
              {list.map((m) => (
                <div key={m.id} onClick={() => openMail(m)} className="flex items-start gap-3 px-1 py-3 border-b border-white/10 cursor-pointer hover:bg-white/[0.04]">
                  <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-[13px] font-medium shrink-0">{m.initials}</div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-baseline justify-between gap-2">
                      <span className={`text-[15px] truncate ${m.unread ? 'font-semibold text-white' : 'text-gray-300'}`}>{m.sender}</span>
                      <span className="text-[12px] text-gray-500 shrink-0">{m.date}</span>
                    </div>
                    <div className={`text-[14px] truncate ${m.unread ? 'text-white' : 'text-gray-400'}`}>{m.subject}</div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className={`text-[11px] px-2 py-0.5 rounded border ${CAT_STYLE[m.cat]}`}>{m.cat}</span>
                      <span className="text-[12px] text-gray-500 truncate">{m.body}</span>
                    </div>
                  </div>
                  <button onClick={(e) => toggleStar(m.id, e)} className="bg-transparent border-0 p-1 cursor-pointer" aria-label="В избранное">
                    <Star className={`w-4 h-4 ${m.isStarred ? 'fill-amber-300 text-amber-300' : 'text-gray-500'}`} />
                  </button>
                </div>
              ))}
            </div>
          </>
        ) : (
          <div className="flex-1 overflow-y-auto">
            <div className="flex items-center justify-between mb-3">
              <button onClick={() => setSelected(null)} className="flex items-center gap-1.5 text-[14px] text-gray-300 bg-transparent border-0 cursor-pointer p-1">
                <ArrowLeft className="w-4 h-4" /> Входящие
              </button>
              <div className="flex items-center gap-1">
                <button onClick={(e) => toggleStar(selected.id, e)} className="p-2 bg-transparent border-0 cursor-pointer" aria-label="В избранное">
                  <Star className={`w-5 h-5 ${emails.find((x) => x.id === selected.id)?.isStarred ? 'fill-amber-300 text-amber-300' : 'text-gray-300'}`} />
                </button>
                <button onClick={() => showToast('Письмо переслано')} className="p-2 bg-transparent border-0 cursor-pointer text-gray-300" aria-label="Переслать"><Forward className="w-5 h-5" /></button>
                <button onClick={() => remove(selected.id)} className="p-2 bg-transparent border-0 cursor-pointer text-gray-300" aria-label="Удалить"><Trash2 className="w-5 h-5" /></button>
              </div>
            </div>

            <h1 className="text-[20px] leading-snug">{selected.subject}</h1>
            <span className={`inline-block mt-2 text-[12px] px-2 py-0.5 rounded border ${CAT_STYLE[selected.cat]}`}>{selected.cat}</span>

            <div className="flex items-center gap-3 mt-4">
              <div className="w-11 h-11 rounded-full bg-white/10 flex items-center justify-center text-[14px] font-medium">{selected.initials}</div>
              <div className="min-w-0">
                <div className="text-[15px] font-medium truncate">{selected.sender}</div>
                <div className="text-[12px] text-gray-400 truncate">{selected.email} · {selected.date}</div>
              </div>
            </div>

            <p className="text-[15px] leading-relaxed mt-5 text-gray-100">{selected.body}</p>

            {selected.attachment && (
              <div className="mt-4 inline-flex items-center gap-2 px-3 py-2 rounded-lg border border-white/15 bg-white/[0.05] text-[13px]">
                <Paperclip className="w-4 h-4" /> {selected.attachment}
              </div>
            )}

            <div className="mt-6 rounded-xl border border-white/15 p-3">
              <div className="flex items-center gap-2 text-[13px] text-gray-400 mb-2"><Reply className="w-4 h-4" /> Ответить: {selected.sender}</div>
              <textarea value={reply} onChange={(e) => setReply(e.target.value)} rows={3} placeholder="Введите ответ..." className="w-full bg-transparent outline-none text-[15px] text-white placeholder-gray-500 resize-none" />
              <div className="flex justify-end">
                <button onClick={sendReply} className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#8f9bff] text-[#0b0d13] text-[14px] font-medium border-0 cursor-pointer">
                  <Send className="w-4 h-4" /> Отправить
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </ToolWrapper>
  );
};
