import React, { useState, useEffect, useRef } from 'react';
import { soundManager, triggerHaptic } from '../../utils/soundEffects';

interface Plane {
  id: number;
  call: string;
  ang: number; // положение, градусы
  r: number; // расстояние от центра (0..1)
  head: number; // курс, градусы
  speed: number;
  alt: number;
  flicker: boolean;
}

const CALLS = ['SU1204', 'S7-318', 'DP405', 'UT722', 'U6-91', 'FV6054', 'N4-210', 'AFL1812', 'DLH45', 'BAW233', 'UAE72', 'THY11', 'QTR330', 'LOT52'];

const makePlanes = (): Plane[] =>
  CALLS.map((call, i) => ({
    id: i,
    call,
    ang: Math.random() * 360,
    r: 0.15 + Math.random() * 0.8,
    head: Math.random() * 360,
    speed: 0.0006 + Math.random() * 0.0012,
    alt: 200 + Math.floor(Math.random() * 380) * 10 / 10,
    flicker: i % 3 === 0, // каждый третий мигает
  }));

/* ---------- Радар ---------- */

const RadarScreen: React.FC = () => {
  const planesRef = useRef<Plane[]>(makePlanes());
  const [, force] = useState(0);
  const [visible, setVisible] = useState<boolean[]>(() => CALLS.map(() => true));
  const [selected, setSelected] = useState<number | null>(null);

  // движение самолётов
  useEffect(() => {
    const id = window.setInterval(() => {
      planesRef.current = planesRef.current.map((p) => {
        const rad = (p.head * Math.PI) / 180;
        let x = p.r * Math.cos((p.ang * Math.PI) / 180) + Math.sin(rad) * p.speed * 8;
        let y = p.r * Math.sin((p.ang * Math.PI) / 180) - Math.cos(rad) * p.speed * 8;
        let r = Math.hypot(x, y);
        if (r > 0.97) {
          // вышел за радар: появляется с противоположной стороны
          x = -x * 0.9;
          y = -y * 0.9;
          r = Math.hypot(x, y);
        }
        return { ...p, r, ang: (Math.atan2(y, x) * 180) / Math.PI };
      });
      force((n) => n + 1);
    }, 120);
    return () => window.clearInterval(id);
  }, []);

  // «мигающие» самолёты: исчезают и появляются каждые 0,2–0,3 секунды
  useEffect(() => {
    const timers: number[] = [];
    planesRef.current.forEach((p, idx) => {
      if (!p.flicker) return;
      const loop = () => {
        setVisible((v) => v.map((x, i) => (i === idx ? !x : x)));
        timers[idx] = window.setTimeout(loop, 200 + Math.random() * 100);
      };
      timers[idx] = window.setTimeout(loop, 200 + Math.random() * 100);
    });
    return () => timers.forEach((t) => window.clearTimeout(t));
  }, []);

  const planes = planesRef.current;
  const sel = selected !== null ? planes[selected] : null;

  return (
    <div className="space-y-3">
      <div className="rounded-2xl relative bg-black border border-white/25" style={{ aspectRatio: '1 / 1' }}>
        <style>{`@keyframes radar-sweep { to { transform: rotate(360deg); } }`}</style>
        <svg viewBox="-100 -100 200 200" className="w-full h-full block">
          {[25, 50, 75, 95].map((r) => (
            <circle key={r} cx="0" cy="0" r={r} fill="none" stroke="#0d6b2f" strokeWidth="0.5" />
          ))}
          <line x1="-95" y1="0" x2="95" y2="0" stroke="#0d6b2f" strokeWidth="0.4" />
          <line x1="0" y1="-95" x2="0" y2="95" stroke="#0d6b2f" strokeWidth="0.4" />
          <text x="-3" y="-96" fontSize="6" fill="#19d35a">N</text>
          <text x="96" y="2" fontSize="6" fill="#19d35a">E</text>
          <text x="-3" y="102" fontSize="6" fill="#19d35a">S</text>
          <text x="-101" y="2" fontSize="6" fill="#19d35a">W</text>
          <g style={{ transformOrigin: '0 0', animation: 'radar-sweep 3.2s linear infinite' }}>
            <path d="M0 0 L95 0 A95 95 0 0 0 82 -48 Z" fill="rgba(25,211,90,0.28)" />
            <line x1="0" y1="0" x2="95" y2="0" stroke="#19ff6a" strokeWidth="0.8" />
          </g>
          {planes.map((p, i) => {
            if (!visible[i]) return null;
            const x = p.r * 95 * Math.cos((p.ang * Math.PI) / 180);
            const y = p.r * 95 * Math.sin((p.ang * Math.PI) / 180);
            const on = selected === i;
            return (
              <g key={p.id} transform={`translate(${x} ${y})`} onClick={() => setSelected(i)} style={{ cursor: 'pointer' }}>
                <circle r="6" fill="transparent" />
                <polygon points="0,-3.2 2.2,2.6 0,1.4 -2.2,2.6" fill={on ? '#ffffff' : '#19ff6a'} transform={`rotate(${p.head})`} />
                <text x="4" y="-3" fontSize="3.6" fill="#19ff6a">{p.call}</text>
              </g>
            );
          })}
        </svg>
        <div className="absolute top-2 left-2 text-[12px] text-[#19ff6a]">РЛС · дальность 250 км</div>
      </div>

      <div className="rounded-2xl border border-white/25 p-3 text-[15px] min-h-[64px]">
        {sel ? (
          <div className="flex justify-between gap-3">
            <div>
              <div className="text-[12px] uppercase tracking-[0.02em] font-medium">Рейс {sel.call}</div>
              <div>Курс {Math.round(sel.head)}°, высота {Math.round(sel.alt * 10 + 2000)} м</div>
            </div>
            <div className="text-right text-gray-400">Скорость {Math.round(sel.speed * 600000)} км/ч</div>
          </div>
        ) : (
          <span className="text-gray-400">Нажмите на самолёт на радаре, чтобы увидеть данные рейса</span>
        )}
      </div>
    </div>
  );
};

/* ---------- Аэропорт ---------- */

type Phase = 'idle' | 'approach' | 'boom';

const AirportScreen: React.FC = () => {
  const [phase, setPhase] = useState<Phase>('idle');
  const [shake, setShake] = useState(false);

  // каждые 20 секунд с шансом 33% самолёт летит прямо на пользователя
  useEffect(() => {
    const id = window.setInterval(() => {
      if (Math.random() < 0.33) {
        setPhase('approach');
        window.setTimeout(() => {
          setPhase('boom');
          setShake(true);
          soundManager.playExplosion();
          triggerHaptic('heavy');
          window.setTimeout(() => setShake(false), 900);
          window.setTimeout(() => setPhase('idle'), 2600);
        }, 2200);
      }
    }, 20000);
    return () => window.clearInterval(id);
  }, []);

  return (
    <div className="space-y-3">
      <div
        className="rounded-2xl relative border border-white/25 overflow-hidden bg-white/10"
        style={{ aspectRatio: '4 / 5', animation: shake ? 'apt-shake 0.1s linear 9' : undefined }}
      >
        <style>{`
          @keyframes apt-fly-a { from { transform: translateX(-30%) translateY(0) } to { transform: translateX(130%) translateY(-18px) } }
          @keyframes apt-fly-b { from { transform: translateX(130%) scaleX(-1) } to { transform: translateX(-30%) scaleX(-1) } }
          @keyframes apt-attack { 0% { transform: translate(-50%,-50%) scale(0.05); opacity: .8 } 100% { transform: translate(-50%,-50%) scale(14); opacity: 1 } }
          @keyframes apt-flash { 0% { opacity: 1 } 100% { opacity: 0 } }
          @keyframes apt-ring { 0% { transform: translate(-50%,-50%) scale(.2); opacity: 1 } 100% { transform: translate(-50%,-50%) scale(6); opacity: 0 } }
          @keyframes apt-part { 0% { transform: translate(0,0) rotate(0); opacity: 1 } 100% { transform: translate(var(--dx),var(--dy)) rotate(var(--rot)); opacity: 0 } }
          @keyframes apt-shake { 0%{transform:translate(0,0)} 25%{transform:translate(-8px,5px)} 50%{transform:translate(7px,-6px)} 75%{transform:translate(-6px,-5px)} 100%{transform:translate(0,0)} }
        `}</style>

        {/* небо и здания */}
        <div className="rounded-2xl absolute inset-x-0 bottom-0 h-[34%] bg-[#cfcfcf] border-t border-white/25" />
        <div className="absolute left-0 right-0 bottom-[10%] h-[2px] bg-black opacity-40" />
        <div className="absolute left-[12%] bottom-[34%] w-6 h-[26%] bg-black" />
        <div className="absolute left-[10.5%] bottom-[58%] w-9 h-4 bg-black" />
        <div className="rounded-2xl absolute left-[30%] bottom-[34%] w-24 h-[10%] bg-[#8a8a8a] border border-white/25" />
        <div className="rounded-2xl absolute right-[12%] bottom-[34%] w-16 h-[8%] bg-[#8a8a8a] border border-white/25" />
        {[0, 1, 2, 3, 4, 5].map((i) => (
          <div key={i} className="absolute bottom-[16%] h-1 bg-[#151826]" style={{ left: `${8 + i * 15}%`, width: '8%' }} />
        ))}

        {/* самолёты вдоль полосы */}
        <div className="absolute left-0 top-[26%] text-4xl" style={{ animation: 'apt-fly-a 16s linear infinite' }}>✈️</div>
        <div className="absolute left-0 top-[44%] text-3xl" style={{ animation: 'apt-fly-b 22s linear infinite', animationDelay: '-8s' }}>✈️</div>
        <div className="absolute left-0 top-[14%] text-2xl" style={{ animation: 'apt-fly-a 28s linear infinite', animationDelay: '-14s' }}>✈️</div>

        <div className="absolute top-2 left-2 text-[12px] uppercase tracking-[0.02em] font-medium">Аэропорт · камера 2</div>

        {/* самолёт летит на пользователя */}
        {phase === 'approach' && (
          <div className="absolute left-1/2 top-[40%] text-5xl" style={{ animation: 'apt-attack 2.2s cubic-bezier(.5,0,1,.6) forwards' }}>
            ✈️
          </div>
        )}

        {/* взрыв */}
        {phase === 'boom' && (
          <>
            <div className="absolute inset-0 bg-[#151826]" style={{ animation: 'apt-flash 0.7s ease-out forwards' }} />
            <div className="absolute left-1/2 top-1/2 text-[9rem]" style={{ transform: 'translate(-50%,-50%)', animation: 'apt-flash 2s ease-out forwards' }}>💥</div>
            {[0, 1, 2].map((i) => (
              <div key={i} className="rounded-2xl absolute left-1/2 top-1/2 w-32 h-32 border-4 border-white/25" style={{ animation: `apt-ring ${0.9 + i * 0.3}s ease-out ${i * 0.12}s forwards` }} />
            ))}
            {Array.from({ length: 18 }).map((_, i) => {
              const a = (i / 18) * Math.PI * 2;
              return (
                <div
                  key={i}
                  className="absolute left-1/2 top-1/2 text-3xl"
                  style={{
                    ['--dx' as string]: `${Math.cos(a) * (140 + (i % 4) * 60)}px`,
                    ['--dy' as string]: `${Math.sin(a) * (140 + (i % 4) * 60)}px`,
                    ['--rot' as string]: `${i * 90}deg`,
                    animation: 'apt-part 1.4s ease-out forwards',
                  } as React.CSSProperties}
                >
                  {i % 3 === 0 ? '🔥' : i % 3 === 1 ? '✈️' : '💨'}
                </div>
              );
            })}
          </>
        )}
      </div>

      <div className="rounded-2xl border border-white/25 p-3 text-[15px]">
        <div className="text-[12px] uppercase tracking-[0.02em] font-medium">Табло</div>
        <div className="mt-1 text-gray-400">Борты на полосе: 3. Следите за небом.</div>
      </div>
    </div>
  );
};

export const FlightTracker: React.FC = () => {
  const [view, setView] = useState<'radar' | 'airport'>('radar');
  return (
    <div className="space-y-3">
      <div className="rounded-2xl grid grid-cols-2 border border-white/25">
        {([
          ['radar', 'Радар'],
          ['airport', 'Аэропорт'],
        ] as const).map(([id, label]) => (
          <button
            key={id}
            onClick={() => setView(id)}
            className={`rounded-2xl py-2.5 text-[12px] uppercase tracking-[0.02em] cursor-pointer border-0 ${view === id ? 'bg-[#8f9bff] text-[#0b0d13]' : 'bg-white/[0.06] text-white'}`}
          >
            {label}
          </button>
        ))}
      </div>
      {view === 'radar' ? <RadarScreen /> : <AirportScreen />}
    </div>
  );
};
