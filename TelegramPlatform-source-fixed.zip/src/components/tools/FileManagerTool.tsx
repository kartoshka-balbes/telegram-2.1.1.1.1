import React, { useState, useRef } from 'react';
import { ArrowLeft, Search, MoreVertical, Folder, File as FileIcon, X, Trash2 } from 'lucide-react';

interface ToolProps {
  onClose: () => void;
}

interface Entry {
  name: string;
  folder: boolean;
  size: number; // байты, для папок — количество элементов
  date: string;
}

const VIRUS_NAMES = [
  'секретные вирусы🤫🤫',
  'вирусы😮😮',
  'очень опасные вирусы😧',
  'секретный вирус🤫',
  'страшные вирусы😲',
  'страшилка с вирусами🤫',
  'вирусы с вирусами😮',
  'игры с вирусами😯',
  'вирусы с играми🤫🤫',
  'точно самые опасные вирусы😲',
  'самые крутые вирусы😧😧',
];

const STANDARD = ['Alarms', 'Android', 'DCIM', 'Documents', 'Download', 'Movies', 'Music', 'Notifications', 'Pictures', 'Podcasts', 'Ringtones'];
const MONTHS = ['янв.', 'февр.', 'мар.', 'апр.', 'мая', 'июн.', 'июл.', 'авг.', 'сент.', 'окт.', 'нояб.', 'дек.'];

const hash = (s: string) => {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
};
const rng = (seed: number) => {
  let a = seed;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
};

const fmtSize = (b: number) => {
  if (b < 1024) return `${b} Б`;
  if (b < 1024 * 1024) return `${Math.round(b / 1024)} КБ`;
  if (b < 1024 * 1024 * 1024) return `${(b / 1024 / 1024).toFixed(1).replace('.', ',')} МБ`;
  return `${(b / 1024 / 1024 / 1024).toFixed(1).replace('.', ',')} ГБ`;
};

// Содержимое любой папки создаётся по её пути, поэтому оно всегда одинаковое
const listDir = (path: string): Entry[] => {
  const r = rng(hash(path));
  const date = () => `${1 + Math.floor(r() * 28)} ${MONTHS[Math.floor(r() * 12)]}`;
  const out: Entry[] = [];
  if (path === '') {
    STANDARD.forEach((n) => out.push({ name: n, folder: true, size: 3 + Math.floor(r() * 12), date: date() }));
  }
  const count = 5 + Math.floor(r() * 7);
  const pool = [...VIRUS_NAMES].sort(() => r() - 0.5).slice(0, Math.min(count, VIRUS_NAMES.length));
  pool.forEach((n) => {
    const folder = r() < 0.38;
    out.push({ name: n, folder, size: folder ? 4 + Math.floor(r() * 11) : Math.floor(2000 + r() * 40000000), date: date() });
  });
  return out;
};

export const FileManagerTool: React.FC<ToolProps> = ({ onClose }) => {
  const [path, setPath] = useState<string[]>([]);
  const [removed, setRemoved] = useState<Record<string, string[]>>({});
  const [selected, setSelected] = useState<string[]>([]);
  const [info, setInfo] = useState<Entry | null>(null);
  const [query, setQuery] = useState('');
  const [searching, setSearching] = useState(false);
  const pressTimer = useRef<number | null>(null);
  const longPressed = useRef(false);

  const key = path.join('/');
  const entries = listDir(key)
    .filter((e) => !(removed[key] || []).includes(e.name))
    .filter((e) => !query.trim() || e.name.toLowerCase().includes(query.trim().toLowerCase()));

  const goBack = () => {
    if (selected.length) return setSelected([]);
    if (searching) {
      setSearching(false);
      setQuery('');
      return;
    }
    if (path.length === 0) onClose();
    else setPath(path.slice(0, -1));
  };

  const open = (e: Entry) => {
    if (e.folder) {
      setPath([...path, e.name]);
      setQuery('');
      setSearching(false);
    } else {
      setInfo(e);
    }
  };

  const start = (e: Entry) => {
    longPressed.current = false;
    pressTimer.current = window.setTimeout(() => {
      longPressed.current = true;
      setSelected((s) => (s.includes(e.name) ? s : [...s, e.name]));
    }, 450);
  };
  const end = () => {
    if (pressTimer.current) window.clearTimeout(pressTimer.current);
  };

  const click = (e: Entry) => {
    if (longPressed.current) {
      longPressed.current = false;
      return;
    }
    if (selected.length) setSelected((s) => (s.includes(e.name) ? s.filter((x) => x !== e.name) : [...s, e.name]));
    else open(e);
  };

  const del = () => {
    setRemoved((r) => ({ ...r, [key]: [...(r[key] || []), ...selected] }));
    setSelected([]);
  };

  const title = selected.length ? `Выбрано: ${selected.length}` : path.length ? path[path.length - 1] : 'Файлы';

  return (
    <div className="fixed inset-0 z-40 bg-[#0b0d13]/[0.06] text-white flex flex-col select-none">
      {/* Верхняя панель */}
      <div className="rounded-2xl flex items-center gap-3 px-3 py-2.5 border-b border-white/25">
        <button onClick={goBack} className="rounded-2xl p-1.5 bg-transparent border-0 cursor-pointer" aria-label="Назад">
          {selected.length ? <X className="w-5 h-5" /> : <ArrowLeft className="w-5 h-5" />}
        </button>
        {searching ? (
          <input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Поиск в папке"
            className="rounded-2xl flex-1 min-w-0 bg-transparent outline-none border-0 border-b border-white/25 text-[15px] py-1"
          />
        ) : (
          <h2 className="flex-1 min-w-0 truncate text-[20px]">{title}</h2>
        )}
        {selected.length > 0 ? (
          <button onClick={del} className="rounded-2xl p-1.5 bg-transparent border-0 cursor-pointer" aria-label="Удалить">
            <Trash2 className="w-5 h-5" />
          </button>
        ) : (
          <>
            <button onClick={() => setSearching(!searching)} className="rounded-2xl p-1.5 bg-transparent border-0 cursor-pointer" aria-label="Поиск">
              <Search className="w-5 h-5" />
            </button>
            <button className="rounded-2xl p-1.5 bg-transparent border-0 cursor-pointer" aria-label="Меню">
              <MoreVertical className="w-5 h-5" />
            </button>
          </>
        )}
      </div>

      {/* Путь */}
      <div className="rounded-2xl px-4 py-2 text-[12px] text-gray-400 border-b border-white/10 overflow-x-auto whitespace-nowrap">
        <button onClick={() => setPath([])} className="rounded-2xl bg-transparent border-0 p-0 cursor-pointer text-white underline">Внутренняя память</button>
        {path.map((p, i) => (
          <span key={i}>
            {' › '}
            <button onClick={() => setPath(path.slice(0, i + 1))} className="rounded-2xl bg-transparent border-0 p-0 cursor-pointer text-white underline">
              {p}
            </button>
          </span>
        ))}
      </div>

      {/* Список */}
      <div className="flex-1 overflow-y-auto">
        {entries.length === 0 && <div className="px-5 py-10 text-[15px] text-gray-400">Папка пуста</div>}
        {entries.map((e) => {
          const on = selected.includes(e.name);
          return (
            <div
              key={e.name}
              onPointerDown={() => start(e)}
              onPointerUp={end}
              onPointerLeave={end}
              onPointerCancel={end}
              onContextMenu={(ev) => ev.preventDefault()}
              onClick={() => click(e)}
              className={`rounded-2xl flex items-center gap-4 px-4 py-3 border-b border-white/10 cursor-pointer ${on ? 'bg-white/15' : 'hover:bg-white/10'}`}
            >
              <div className="rounded-2xl w-10 h-10 border border-white/25 flex items-center justify-center shrink-0">
                {e.folder ? <Folder className="w-5 h-5" /> : <FileIcon className="w-5 h-5" />}
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-[15px] truncate">{e.name}</div>
                <div className="text-[12px] text-gray-400">
                  {e.folder ? `${e.size} элем.` : fmtSize(e.size)} · {e.date}
                </div>
              </div>
              {on && <span className="text-[15px]">✓</span>}
            </div>
          );
        })}
      </div>

      {/* Нижняя информация */}
      <div className="rounded-2xl px-4 py-2 border-t border-white/25 text-[12px] flex justify-between">
        <span>Свободно 41,2 ГБ из 128 ГБ</span>
        <span>{entries.length} элем.</span>
      </div>

      {/* Свойства файла */}
      {info && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-5" onClick={() => setInfo(null)}>
          <div className="rounded-2xl w-full max-w-sm bg-[#151826] border border-white/15 p-5" onClick={(e) => e.stopPropagation()}>
            <div className="text-[12px] uppercase tracking-[0.02em] font-medium">Свойства файла:</div>
            <div className="text-[20px] mt-2 leading-tight break-words">{info.name}</div>
            <div className="rounded-2xl mt-3 border border-white/10 text-[15px]">
              <div className="rounded-2xl flex justify-between px-3 py-2 border-b border-white/10"><span className="text-gray-400">Размер</span><span>{fmtSize(info.size)}</span></div>
              <div className="rounded-2xl flex justify-between px-3 py-2 border-b border-white/10"><span className="text-gray-400">Изменён</span><span>{info.date}</span></div>
              <div className="flex justify-between px-3 py-2"><span className="text-gray-400">Тип</span><span>Неизвестно</span></div>
            </div>
            <p className="text-[15px] mt-3">Нет приложения для открытия этого типа файлов.</p>
            <button onClick={() => setInfo(null)} className="rounded-2xl mt-4 w-full py-3 border border-white/25 bg-[#8f9bff] text-[#0b0d13] text-[15px] cursor-pointer">Закрыть</button>
          </div>
        </div>
      )}
    </div>
  );
};
