import React, { useState } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { Folder, ChevronRight, ShieldAlert, X, Monitor } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

const REGISTRY_FOLDERS = [
  { id: 'hkcr', name: 'HKEY_CLASSES_ROOT' },
  { id: 'hkcu', name: 'HKEY_CURRENT_USER' },
  { id: 'hklm', name: 'HKEY_LOCAL_MACHINE' },
  { id: 'hku', name: 'HKEY_USERS' },
  { id: 'hkcc', name: 'HKEY_CURRENT_CONFIG' },
];

const MENU = ['Файл', 'Правка', 'Вид', 'Избранное', 'Справка'];

export const RegistryEditorTool: React.FC<ToolProps> = ({ onClose }) => {
  const [showForbiddenModal, setShowForbiddenModal] = useState(false);
  const [active, setActive] = useState<string | null>(null);

  const handleFolderClick = (id: string) => {
    setActive(id);
    soundManager.playSiren();
    setShowForbiddenModal(true);
  };

  return (
    <ToolWrapper title="Редактор реестра" onClose={onClose}>
      <div className="relative flex-1 flex flex-col max-w-3xl mx-auto w-full py-1 select-none">
        {/* Окно в стиле regedit */}
        <div className="flex-1 flex flex-col bg-[#f0f0f0] text-black border border-[#6d6d6d] shadow-2xl overflow-hidden" style={{ fontFamily: "'Segoe UI', Tahoma, sans-serif" }}>
          {/* Заголовок окна */}
          <div className="flex items-center justify-between bg-white px-2 h-8 border-b border-[#d9d9d9]">
            <div className="flex items-center gap-2 text-[12px]">
              <span className="w-4 h-4 bg-[#1e6fd9] inline-block" />
              Редактор реестра
            </div>
            <div className="flex text-[12px]">
              <span className="px-3 py-1">—</span>
              <span className="px-3 py-1">▢</span>
              <span className="px-3 py-1 hover:bg-[#e81123] hover:text-white">✕</span>
            </div>
          </div>

          {/* Меню */}
          <div className="flex bg-white border-b border-[#d9d9d9] text-[12px]">
            {MENU.map((m) => (
              <span key={m} className="px-3 py-1.5 hover:bg-[#e5f3ff] cursor-default">{m}</span>
            ))}
          </div>

          {/* Адресная строка */}
          <div className="bg-white border-b border-[#d9d9d9] px-2 py-1.5 text-[12px]">
            <div className="border border-[#aaa] px-2 py-1 bg-white">{active ? REGISTRY_FOLDERS.find((f) => f.id === active)?.name : 'Компьютер'}</div>
          </div>

          {/* Панели */}
          <div className="flex flex-1 min-h-[360px]">
            {/* Дерево */}
            <div className="w-[46%] sm:w-[40%] bg-white border-r border-[#d9d9d9] overflow-y-auto py-1 text-[13px]">
              <div className="flex items-center gap-1.5 px-2 py-0.5">
                <Monitor className="w-4 h-4 text-[#444]" />
                <span>Компьютер</span>
              </div>
              {REGISTRY_FOLDERS.map((folder) => (
                <div
                  key={folder.id}
                  onClick={() => handleFolderClick(folder.id)}
                  className={`flex items-center gap-1 pl-6 pr-2 py-0.5 cursor-pointer ${active === folder.id ? 'bg-[#cce8ff]' : 'hover:bg-[#e5f3ff]'}`}
                >
                  <ChevronRight className="w-3.5 h-3.5 text-[#777]" />
                  <Folder className="w-4 h-4 text-[#e8b400] fill-[#ffd75a]" />
                  <span className="truncate">{folder.name}</span>
                </div>
              ))}
            </div>

            {/* Значения */}
            <div className="flex-1 bg-white overflow-hidden text-[12px]">
              <div className="grid grid-cols-[1.1fr_0.8fr_1.4fr] bg-white border-b border-[#d9d9d9] text-[#444]">
                {['Имя', 'Тип', 'Значение'].map((h) => (
                  <div key={h} className="px-2 py-1 border-r border-[#e6e6e6]">{h}</div>
                ))}
              </div>
              <div className="grid grid-cols-[1.1fr_0.8fr_1.4fr] px-0 py-1 text-[#222]">
                <div className="px-2 truncate">(По умолчанию)</div>
                <div className="px-2">REG_SZ</div>
                <div className="px-2 truncate">(значение не присвоено)</div>
              </div>
            </div>
          </div>

          {/* Строка состояния */}
          <div className="bg-[#f0f0f0] border-t border-[#d9d9d9] px-2 py-1 text-[12px] text-[#444]">{active ? 'Компьютер\\' + REGISTRY_FOLDERS.find((f) => f.id === active)?.name : 'Компьютер'}</div>
        </div>

        {/* Forbidden Modal */}
        {showForbiddenModal && (
          <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-6">
            <div className="w-full max-w-sm bg-white text-black border border-[#6d6d6d] shadow-2xl relative" style={{ fontFamily: "'Segoe UI', Tahoma, sans-serif" }}>
              <div className="flex items-center justify-between h-8 pl-3 bg-white border-b border-[#d9d9d9] text-[12px]">
                <span>Редактор реестра</span>
                <button onClick={() => setShowForbiddenModal(false)} className="w-10 h-8 bg-transparent border-0 hover:bg-[#e81123] hover:text-white cursor-pointer" aria-label="Закрыть">
                  <X className="w-4 h-4 mx-auto" />
                </button>
              </div>
              <div className="p-5 flex gap-4">
                <ShieldAlert className="w-12 h-12 text-[#e81123] shrink-0" />
                <div>
                  <h2 className="text-[20px] text-[#e81123] leading-tight mb-2">ЗАПРЕЩЕНО</h2>
                  <p className="text-[13px] text-[#222]">У вас недостаточно прав администратора для изменения ключей системного реестра.</p>
                </div>
              </div>
              <div className="bg-[#f0f0f0] px-4 py-3 flex justify-end border-t border-[#d9d9d9]">
                <button onClick={() => setShowForbiddenModal(false)} className="px-6 py-1.5 bg-[#e1e1e1] hover:bg-[#e5f1fb] border border-[#adadad] hover:border-[#0078d7] text-[13px] cursor-pointer">
                  Закрыть
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </ToolWrapper>
  );
};
