import React, { StrictMode, ReactNode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  declare props: Readonly<ErrorBoundaryProps>;
  declare state: Readonly<ErrorBoundaryState>;

  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('App runtime error caught by boundary:', error, errorInfo);
    // Автоматически сбрасываем временные данные и перезагружаем —
    // чтобы пользователь никогда не видел застрявший экран ошибки
    try {
      localStorage.clear();
      sessionStorage.clear();
    } catch {}
    setTimeout(() => {
      window.location.reload();
    }, 80);
  }

  render(): ReactNode {
    // Не показываем экран ошибки — сразу пытаемся восстановиться
    // (componentDidCatch уже запустил очистку + reload)
    if (this.state.hasError) {
      return (
        <div className="min-h-screen w-full bg-[#0b0d13] flex items-center justify-center">
          <div className="text-[#8f9bff] text-sm animate-pulse">Перезагрузка…</div>
        </div>
      );
    }

    return this.props.children;
  }
}

const rootElement = document.getElementById('root');
if (rootElement) {
  createRoot(rootElement).render(
    <StrictMode>
      <ErrorBoundary>
        <App />
      </ErrorBoundary>
    </StrictMode>
  );
}
