import React, { StrictMode, ReactNode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  declare props: Readonly<ErrorBoundaryProps>;
  declare state: Readonly<ErrorBoundaryState>;

  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('App runtime error:', error, errorInfo);
  }

  handleReset = () => {
    try {
      localStorage.clear();
      sessionStorage.clear();
    } catch {}
    window.location.reload();
  };

  handleSoftReload = () => {
    window.location.reload();
  };

  render(): ReactNode {
    if (this.state.hasError) {
      const msg = this.state.error?.message || 'Неизвестная ошибка';
      const stack = this.state.error?.stack?.slice(0, 400) || '';

      return (
        <div className="min-h-screen w-full bg-slate-950 text-white flex flex-col items-center justify-center p-6 text-center">
          <div className="w-16 h-16 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center text-3xl mb-4 border border-rose-500/30">
            ⚠️
          </div>
          <h1 className="text-xl font-bold mb-2">Ошибка запуска</h1>
          <p className="text-slate-400 text-sm max-w-md mb-3">
            Приложение упало при загрузке. Ниже текст ошибки — его можно скопировать.
          </p>
          <pre className="text-left text-xs bg-black/50 border border-white/10 rounded-xl p-3 max-w-md w-full overflow-auto mb-4 text-rose-200 whitespace-pre-wrap break-all">
            {msg}
            {stack ? '\n\n' + stack : ''}
          </pre>
          <div className="flex flex-col sm:flex-row gap-2 w-full max-w-md">
            <button
              onClick={this.handleSoftReload}
              className="flex-1 px-4 py-2.5 bg-white/10 hover:bg-white/15 text-white font-semibold rounded-xl"
            >
              Просто перезагрузить
            </button>
            <button
              onClick={this.handleReset}
              className="flex-1 px-4 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-semibold rounded-xl"
            >
              Сбросить данные и перезагрузить
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

const rootElement = document.getElementById('root');
if (rootElement) {
  createRoot(rootElement).render(
    <StrictMode>
      <ErrorBoundary>
        <App />
      </ErrorBoundary>
    </StrictMode>
  );
}
